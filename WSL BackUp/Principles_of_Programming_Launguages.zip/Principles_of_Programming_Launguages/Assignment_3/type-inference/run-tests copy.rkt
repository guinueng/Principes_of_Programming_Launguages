#lang racket

(require "test-infra.scm")
(require "parser.scm")
(require "datatype.scm")
(require "inferrer.scm")
(require "utils.scm")

;;;;;;;;;;;;;;;; tests ;;;;;;;;;;;;;;;;

(define test-list
  '(
    ;; Format:
    ;; (test-name explicit-or-implicit-ref program environment expected-output)
    (const-exp-1 "11" int)
    (const-exp-2 "-10" int)
    (add-exp-1 "(+ 5 2)" int)
    (diff-exp-1 "(- 10 4)" int)
    (zero?-1 "(zero? 0)" bool)
    (zero?-2 "(zero? 1)" bool)
    (less-than-1 "(< 5 10)" bool)
    (less-than-2 "(< 11 6)" bool)
    (not-1 "(not (< 5 10))" bool)
    (not-2 "(not (< 11 6))" bool)
    (if-exp-1 "(if (zero? 0) 1 2)" int)
    (if-exp-2 "(if (zero? 1) 1 2)" int)
    (lambda-exp-1 "(lambda ((x ?)) x)" (tvar-1 -> tvar-1)) ; tvar-1 can be any type
    (lambda-exp-2 "(lambda ((x ?)) (+ x 1))" (int -> int))
    (lambda-exp-3 "(lambda ((x ?)) (zero? x))" (int -> bool))
    (lambda-exp-4 "(lambda ((x ?)) (+ x x))" (int -> int))
    (lambda-exp-5 "(lambda ((x ?) (y ?)) (+ x y))" ((int int) -> int))
    (lambda-exp-6 "(lambda ((x ?) (y ?) (z ?)) (+ (+ x y) z))" ((int int int) -> int))
    (lambda-exp-8 "(lambda ((x ?)) (lambda ((y ?)) (+ x y)))" (int -> (int -> int)))
    (lambda-exp-9 "(lambda ((x ?) (y ?)) (< x y))" ((int int) -> bool))
    (lambda-exp-10 "(lambda ((x ?)) (zero? x))" (int -> bool))
    /(letrec-type-error-3 "(letrec ((bool f (lambda ((x int)) (if (zero? x) 0 (+ 1 (f ((- x 1)))))))) f)" "unification failure: bool (actual) != int (expected)")
    ))

;; run : String -> ExpVal
(define run
  (lambda (string)
    (init-var-type-id!)
    (let ((ast (parse string)))
      (begin
        (debug "program: ~a~%" string)
        (debug "ast: ~a~%" ast)
        (let ((result (type-of-program ast)))
          (debug "result: ~a~%" result)
          result)))))

(define run-all
  (lambda ()
    (run-tests! run equal-answer? test-list)))

(run-all)